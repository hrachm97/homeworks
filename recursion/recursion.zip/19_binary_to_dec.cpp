#include <iostream>

int to_number (char a) {
    return (a == '0') ? 0 : 1; 
}

int pow(int n, int e) {
    if (e == 0) return 1;
    return n * pow(n, e - 1);
}

int bin_to_dec(std::string str, int n = 8) {
    if (n == 0) return 0;
    return to_number(str[8 - n]) * pow(2, n - 1) + bin_to_dec(str, n - 1);
}

int main() {
    std::cout << bin_to_dec("01111111");
}